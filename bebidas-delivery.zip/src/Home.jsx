import { useState } from "react";

const produtos = [
  {
    id: 1,
    nome: "Cerveja Heineken",
    preco: 9.99,
    imagem: "https://images.unsplash.com/photo-1600508771845-2742d4f66f52?auto=format&fit=crop&w=500&q=60",
  },
  {
    id: 2,
    nome: "Vinho Tinto",
    preco: 29.99,
    imagem: "https://images.unsplash.com/photo-1600185365483-26d7e2874ccf?auto=format&fit=crop&w=500&q=60",
  },
  {
    id: 3,
    nome: "Vodka Absolut",
    preco: 49.99,
    imagem: "https://images.unsplash.com/photo-1625851165342-8a93c2e1b77b?auto=format&fit=crop&w=500&q=60",
  },
];

export default function Home() {
  const [carrinho, setCarrinho] = useState([]);

  const adicionarAoCarrinho = (produto) => {
    setCarrinho([...carrinho, produto]);
  };

  const total = carrinho.reduce((acc, item) => acc + item.preco, 0).toFixed(2);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Delivery de Bebidas</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {produtos.map((produto) => (
          <div key={produto.id} className="border rounded-2xl shadow">
            <img
              src={produto.imagem}
              alt={produto.nome}
              className="w-full h-48 object-cover rounded-t-2xl"
            />
            <div className="p-4">
              <h2 className="text-xl font-semibold mb-2">{produto.nome}</h2>
              <p className="mb-2">R$ {produto.preco.toFixed(2)}</p>
              <button
                onClick={() => adicionarAoCarrinho(produto)}
                className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
              >
                Adicionar ao carrinho
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-10 border-t pt-6">
        <h2 className="text-2xl font-bold mb-4">Carrinho</h2>
        {carrinho.length === 0 ? (
          <p>Seu carrinho está vazio.</p>
        ) : (
          <ul className="space-y-2">
            {carrinho.map((item, index) => (
              <li key={index} className="flex justify-between">
                <span>{item.nome}</span>
                <span>R$ {item.preco.toFixed(2)}</span>
              </li>
            ))}
          </ul>
        )}
        <div className="mt-4 text-lg font-semibold">Total: R$ {total}</div>
      </div>
    </div>
  );
}
